#### 1 - Agregar  elementos a un HTMLDivElement y aplicarle un estilo

En el archivo `./exercises/1.js` se provee un función para resolver este ejercicio. Dentro de esta función
escriba un código que dado un texto dentro del div `sourceDiv` dado como primer parámetro de la función,
aumente/disminuya el *font-size* cada 6 caracteres partiendo con el tamaño 12.
El aumento debe ser de a `6px` y el resultado debe agregarse en el div llamado `resultDiv` también dado como parametro de la función.

**Nota:** A los espacios en blanco no se les puede aplicar cambio en el *font-size*
